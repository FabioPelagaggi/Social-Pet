package vortex.project.notes.Fragments

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.fragment_display_note.*
import kotlinx.android.synthetic.main.fragment_new_note.*
import vortex.project.notes.Class.Note
import vortex.project.notes.R
import vortex.project.notes.ViewModel.NotesViewModel
import vortex.project.notes.ViewModel.UserViewModel
import java.io.File

class DisplayNoteFragment : Fragment() {

    private lateinit var userViewModel: UserViewModel
    private lateinit var notesViewModel: NotesViewModel
    private lateinit var notesList: List<Note>
    private var pos = 0

    private var firestoreDB: FirebaseFirestore? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        firestoreDB = FirebaseFirestore.getInstance()

        return inflater.inflate(R.layout.fragment_display_note, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let { act ->
            notesViewModel = ViewModelProvider(act).get(NotesViewModel::class.java)
            userViewModel = ViewModelProvider(act).get(UserViewModel::class.java)
            notesList = notesViewModel.notes.value!!
        }

        setUpListeners()
        setUpDisplayNote()
    }
    private fun setUpListeners(){
        displayNoteOkNote_Button.setOnClickListener {
            saveEditedNote()
            findNavController().navigate(R.id.action_displayNoteFragment_to_notesFragment, null)
        }
        displayNoteDeleteNote_Button.setOnClickListener{
            deleteEditedNote(notesList[pos].noteID)
            findNavController().navigate(R.id.action_displayNoteFragment_to_notesFragment, null)
        }
    }

    private fun setUpDisplayNote(){
        notesViewModel.selectedNotePosition.observe(viewLifecycleOwner, Observer { Int ->
            if (Int != null){
                pos = Int
                displayNoteTitle_TextView.setText(notesList[Int].noteTitle)
                displayNoteAnnotations_TextView.setText(notesList[Int].noteAnnotations)
                displayNoteDate_TextView.text = notesList[Int].noteDate
                if(notesList[Int].noteLocation != "") {
                    displayNoteLocation_TextView.text = notesList[Int].noteLocation
                    displayNoteLatitude_TextView.text = notesList[Int].noteLatitude
                    displayNoteLongitude_TextView.text = notesList[Int].noteLongitude
                } else{
                    displayNoteLocation_CardView.visibility = View.GONE
                    displayNoteLatitude_CardView.visibility = View.GONE
                    displayNoteLongitude_CardView.visibility = View.GONE
                }
                if(notesList[Int].noteTemp != "--°C") {
                    displayNoteWeatherCelsius_TextView.text = notesList[Int].noteTemp
                    displayNoteHumidity_TextView.text = notesList[Int].noteHumidity
                    displayNoteWind_TextView.text = notesList[Int].noteWind
                } else{
                    displayNoteWeather_CardView.visibility = View.GONE
                    displayNoteHumidity_CardView.visibility = View.GONE
                    displayNoteWind_CardView.visibility = View.GONE
                }
                if(notesList[Int].notePhoto != "") {
                    displayNotePhoto_ImageView.setImageBitmap(handleBitmap(notesList[Int].notePhoto))
                } else {
                    displayNotePhoto_ImageView.visibility = View.GONE
                }

            }
        })
    }
    private fun saveEditedNote(){
        val notePosition = notesViewModel.selectedNotePosition.value!!
        notesList[notePosition].noteTitle = displayNoteTitle_TextView.text.toString()
        notesList[notePosition].noteAnnotations = displayNoteAnnotations_TextView.text.toString()
        notesList[notePosition].noteDate = displayNoteDate_TextView.text.toString()

        upadateNoteFirebase(displayNoteTitle_TextView.text.toString(), displayNoteAnnotations_TextView.text.toString())

    }
    private fun deleteEditedNote(noteID: String){

        deleteFirebase(noteID)

//        deleteFile()

        Toast.makeText(context, "$noteID deleted", Toast.LENGTH_LONG).show()

    }
    private fun handleBitmap(photo: String): Bitmap {
        val byteArray: ByteArray = Base64.decode(photo, Base64.DEFAULT)
        val bmImage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
        return bmImage
    }
    private fun deleteFile(){
        val noteTitle = notesList[notesViewModel.selectedNotePosition.value!!].noteTitle
        val noteDate = notesList[notesViewModel.selectedNotePosition.value!!].noteDate

        val fileNameTxt = "${noteTitle}_${noteDate}_.txt"
        val file = File(requireActivity().filesDir, fileNameTxt)

        if (file.exists()){
            file.delete()
        }

    }

    private fun deleteFirebase(noteID: String){
        firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes").document(noteID).delete()
    }

    private fun upadateNoteFirebase(noteTitle: String, noteAnnotations: String){

        val data = hashMapOf("noteTitle" to noteTitle, "noteAnnotations" to noteAnnotations)

        firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes").document(notesList[pos].noteID)
            .set(data, SetOptions.merge())
            .addOnSuccessListener { documentReference ->
                Log.e(ContentValues.TAG, "DocumentSnapshot Upadated")
                Toast.makeText(context, "Note has been Upadated on firebase store!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e(ContentValues.TAG, "Error Upadating note document", e)
                Toast.makeText(context, "Note could not be added to firebase store...", Toast.LENGTH_SHORT).show()
            }
    }
}