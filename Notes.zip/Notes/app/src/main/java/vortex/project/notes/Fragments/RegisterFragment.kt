package vortex.project.notes.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_register.*
import vortex.project.notes.R
import vortex.project.notes.ViewModel.UserViewModel

class RegisterFragment : Fragment() {

    private lateinit var userViewModel: UserViewModel
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        auth = FirebaseAuth.getInstance()
        val view = inflater.inflate(R.layout.fragment_register, container, false)
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let {
                act -> userViewModel = ViewModelProviders.of(act).get(UserViewModel::class.java)
        }
        configDrawerMenu()
        setUpListeners()
    }

    private fun setUpListeners(){
        reg_button.setOnClickListener {
            if (checkEmailPass()) {
                saveViewModel()
                doRegister()
            }
        }
    }
    private fun doRegister() {
        auth.createUserWithEmailAndPassword(userViewModel.userEmail.value.toString(), userViewModel.userPass.value.toString())
            .addOnSuccessListener {
                Toast.makeText(context, "Register Success", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_registerFragment_to_loginFragment, null)
            }
            .addOnFailureListener {
                when (it) {
                    is FirebaseAuthWeakPasswordException -> Toast.makeText(context, "Password length error", Toast.LENGTH_SHORT).show()
                    is FirebaseAuthUserCollisionException -> Toast.makeText(context, "E-mail already registered", Toast.LENGTH_SHORT).show()
                    is FirebaseNetworkException -> Toast.makeText(context, " Internet error", Toast.LENGTH_SHORT).show()
                    else -> Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show()
                }
            }

    }
    private fun saveViewModel() {
        userViewModel.userEmail.value = emailReg_EditText.text.toString()
        userViewModel.userPass.value = passwordReg_EditText.text.toString()
    }

    private fun checkEmailPass(): Boolean {
        var check = false

        if (emailReg_EditText.text.toString().isNotEmpty()) {
            if (passwordReg_EditText.text.toString().isNotEmpty()) {
                if (confirmPasswordReg_EditText.text.toString().isNotEmpty()) {
                    if (passwordReg_EditText.text.toString() == confirmPasswordReg_EditText.text.toString()) {
                        check = true
                    } else {Toast.makeText(context, "Passwords don't match", Toast.LENGTH_SHORT).show()}
                } else {Toast.makeText(context, "Confirm Password can't be empty", Toast.LENGTH_SHORT).show()}
            } else {Toast.makeText(context, "Password can't be empty", Toast.LENGTH_SHORT).show()}
        } else {Toast.makeText(context, "E-mail can't be empty", Toast.LENGTH_SHORT).show()}

        return check
    }
    private fun configDrawerMenu(){
        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
        requireActivity().navigationView.menu.findItem(R.id.notesFragment).isVisible = false
        requireActivity().navigationView.menu.findItem(R.id.archiveFragment).isVisible = false
        requireActivity().navigationView.menu.findItem(R.id.loginFragment).isVisible = true
        requireActivity().navigationView.menu.findItem(R.id.logoutFragment).isVisible = false
        requireActivity().navigationView.menu.findItem(R.id.registerFragment).isVisible = false
    }
}