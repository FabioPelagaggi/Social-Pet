package vortex.project.notes.Model

data class Sys(
    val country: String,
    val sunrise: Int,
    val sunset: Int
)