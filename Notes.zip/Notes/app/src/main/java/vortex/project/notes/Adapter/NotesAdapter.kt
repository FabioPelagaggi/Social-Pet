package vortex.project.notes.Adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.MainThread
import androidx.recyclerview.widget.RecyclerView
import vortex.project.notes.Activity.MainActivity
import vortex.project.notes.Class.Note
import vortex.project.notes.Fragments.NotesFragment
import vortex.project.notes.R

class NotesAdapter(var notesList: List<Note?>, private val listener: OnItemClickListener ): RecyclerView.Adapter<NotesAdapter.Viewholder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.note_card, parent, false)
        val viewholder = Viewholder(view)
        return viewholder
    }

    override fun onBindViewHolder(holder: Viewholder, position: Int) {

        holder.noteTitle.text = notesList[position]!!.noteTitle
        holder.noteDate.text = notesList[position]!!.noteDate
    }

    override fun getItemCount(): Int {
        return notesList.size
    }

    inner class Viewholder(itemView: View): RecyclerView.ViewHolder(itemView), View.OnClickListener  {

        val noteTitle: TextView = itemView.findViewById(R.id.noteTitleTextView)
        val noteDate: TextView = itemView.findViewById(R.id.noteDateTextView)
        val noteCard: View = itemView.findViewById(R.id.noteCardView)

        init {
            noteCard.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position: Int = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onItemClick(position)
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    fun changeData(notes: List<Note>){
        notesList = notes
        notifyDataSetChanged()
    }
}