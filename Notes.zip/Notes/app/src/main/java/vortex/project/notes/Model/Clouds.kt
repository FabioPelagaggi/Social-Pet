package vortex.project.notes.Model

data class Clouds(
    val all: Int
)