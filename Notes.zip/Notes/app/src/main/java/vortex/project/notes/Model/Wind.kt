package vortex.project.notes.Model

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)