package vortex.project.notes.Class

import vortex.project.notes.Model.*

class Note(
    var noteID: String = "",
    var noteTitle: String = "",
    var notePhoto: String = "",
    var noteLocation: String = "",
    var noteLatitude: String = "",
    var noteLongitude: String = "",
    var noteDate: String = "",
    var noteAnnotations: String = "",
    var noteTemp: String = "",
    var noteHumidity: String = "",
    var noteWind: String = ""
)