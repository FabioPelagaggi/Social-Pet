package vortex.project.notes.Fragments

import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.facebook.AccessToken
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginResult
import com.facebook.login.widget.LoginButton
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_login.view.*
import vortex.project.notes.Activity.MainActivity
import vortex.project.notes.Class.Note
import vortex.project.notes.R
import vortex.project.notes.ViewModel.NotesViewModel
import vortex.project.notes.ViewModel.UserViewModel

class LoginFragment : Fragment() {

    private lateinit var userViewModel: UserViewModel
    private lateinit var notesViewModel: NotesViewModel
    private lateinit var auth: FirebaseAuth
    private lateinit var callbackManager: CallbackManager
    private var firestoreDB: FirebaseFirestore? = null


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        firestoreDB = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        callbackManager = CallbackManager.Factory.create()

        val view = inflater.inflate(R.layout.fragment_login, container, false)

        view.register_TextView.setOnClickListener {Navigation.findNavController(view).navigate(R.id.action_loginFragment_to_registerFragment)}

        configureFBInput(view)

        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let {act ->
            userViewModel = ViewModelProviders.of(act).get(UserViewModel::class.java)
            notesViewModel = ViewModelProvider(act).get(NotesViewModel::class.java)
        }
        configDrawerMenu()
        setUpListeners()
        setEmailAfterReg()
    }

    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            getUserData()
            findNavController().navigate(R.id.action_loginFragment_to_notesFragment, null)
        }
    }
    private fun configureFBInput(view: View) {

        val facebook_Button = view.findViewById<LoginButton>(R.id.loginWithFacebook_Button)

        facebook_Button.setReadPermissions("email", "public_profile")
        facebook_Button.fragment = this

        signInFacebook(facebook_Button)
    }

    private fun signInFacebook(_login_facebook_button: LoginButton) {
        _login_facebook_button.registerCallback(callbackManager, object : FacebookCallback<LoginResult?> {
            override fun onSuccess(loginResult: LoginResult?) {
                handleFacebookAccessToken(loginResult!!.accessToken)
                Toast.makeText(context, "Authentication Success.", Toast.LENGTH_SHORT).show()
            }

            override fun onCancel() {
                Toast.makeText(context, "Authentication Cancel.", Toast.LENGTH_SHORT).show()
            }

            override fun onError(exception: FacebookException) {
                val messageError = exception.message
                Toast.makeText(context, "$messageError", Toast.LENGTH_SHORT).show()
            }
        })
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        callbackManager.onActivityResult(requestCode, resultCode, data)
    }
    private fun handleFacebookAccessToken(accessToken: AccessToken?) {
        val credential = FacebookAuthProvider.getCredential(accessToken!!.token)
        auth.signInWithCredential(credential)
            .addOnSuccessListener {
                if (it != null) {
                    val userIdData = auth.currentUser?.uid
                    val userEmailData = auth.currentUser?.email
                    userViewModel.userId.value = userIdData
                    userViewModel.userEmail.value = userEmailData
//                    loadUserPostsData()
                    findNavController().navigate(R.id.action_loginFragment_to_notesFragment, null)
                    Toast.makeText(context, "Authentication Success.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Authentication Failed.", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_LONG).show()

            }
    }

    private fun setUpListeners(){
        login_Button.setOnClickListener {
            if (checkLoginEmailPass()){
                doLogIn()
            }
        }
        login_ImageView.setOnClickListener {
            fillLogInfo()
        }
    }
    private fun fillLogInfo(){
        emailLogin_EditText.setText(userViewModel.userEmail.value)
        passwordLogin_EditText.setText(userViewModel.userPass.value)
    }
    private fun setEmailAfterReg(){
        userViewModel.userEmail.observe(viewLifecycleOwner, Observer {
            if (it != null && it.isNotBlank()) {
                emailLogin_EditText.setText(it)
            }
        })
    }
    private fun doLogIn() {
        auth.signInWithEmailAndPassword(emailLogin_EditText.text.toString(), passwordLogin_EditText.text.toString())
            .addOnSuccessListener { taskSnapshot ->
                Log.d(TAG, "signInWithEmail:success")
                Toast.makeText(context, "Authentication Success", Toast.LENGTH_SHORT).show()
                getUserData()
//                loadUserPostsData()
                findNavController().navigate(R.id.action_loginFragment_to_notesFragment, null)
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "signInWithEmail:failure")
                Toast.makeText(context, "Authentication Failure", Toast.LENGTH_SHORT).show()
            }

    }
    private fun getUserData() {
        val userIdData = auth.currentUser?.uid
        val userEmailData = Firebase.auth.currentUser?.email
        userViewModel.userId.value = userIdData
        userViewModel.userEmail.value = userEmailData
    }
    private fun checkLoginEmailPass(): Boolean {
        var check = false

        if (emailLogin_EditText.text.toString().isNotEmpty()) {
            if (passwordLogin_EditText.text.toString().isNotEmpty()) {
                check = true
            } else {Toast.makeText(context, "Password can't be empty", Toast.LENGTH_SHORT).show()}
        } else {Toast.makeText(context, "E-mail can't be empty", Toast.LENGTH_SHORT).show()}

        return check
    }

    private fun configDrawerMenu(){
        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
//        requireActivity().navigationView.menu.findItem(R.id.notesFragment).isVisible = false
//        requireActivity().navigationView.menu.findItem(R.id.archiveFragment).isVisible = false
//        requireActivity().navigationView.menu.findItem(R.id.loginFragment).isVisible = false
//        requireActivity().navigationView.menu.findItem(R.id.logoutFragment).isVisible = false
//        requireActivity().navigationView.menu.findItem(R.id.registerFragment).isVisible = true
    }
    private fun loadUserPostsData() {
        firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    notesViewModel.notes.value = task.result!!.toObjects(Note::class.java)
                }
            }
    }
}