package vortex.project.notes.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class UserViewModel: ViewModel(){
    //Test User
    var userId = MutableLiveData<String>().apply { value = "" }
    var userEmail = MutableLiveData<String>().apply { value = "thomas@shelby.com" }
    var userPass = MutableLiveData<String>().apply { value = "P34kyBl1nd3ers" }
}