package vortex.project.notes.Model

data class Coord(
    val lat: Double,
    val lon: Double
)