package vortex.project.notes.Fragments

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKeys
import com.google.android.gms.ads.AdRequest
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_notes.*
import vortex.project.notes.Adapter.NotesAdapter
import vortex.project.notes.Class.Encrypto
import vortex.project.notes.Class.Note
import vortex.project.notes.Model.*
import vortex.project.notes.R
import vortex.project.notes.ViewModel.NotesViewModel
import vortex.project.notes.ViewModel.UserViewModel
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader


class NotesFragment : Fragment(), NotesAdapter.OnItemClickListener {

    private lateinit var notesViewModel: NotesViewModel
    private lateinit var userViewModel: UserViewModel
    private lateinit var notesList: List<Note>
    private val encrypto = Encrypto()
    private var firestoreDB: FirebaseFirestore? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        firestoreDB = FirebaseFirestore.getInstance()
        setHasOptionsMenu(true)
        val view = inflater.inflate(R.layout.fragment_notes, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let {act ->
            notesViewModel = ViewModelProvider(act).get(NotesViewModel::class.java)
            userViewModel = ViewModelProvider(act).get(UserViewModel::class.java)
            notesList = notesViewModel.notes.value?: listOf()
        }
        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        getInternalFiles()
        updateNotesFirebase()
        configRecycleView()
        subscribe()
        configDrawerMenu()
        displayUserID()
        setUpListeners()
        setUpAdMob()
    }
    private fun configRecycleView() {
        notesRecyclerView.layoutManager = LinearLayoutManager(activity)
        notesRecyclerView.adapter = NotesAdapter(notesList, this)
        notesRecyclerView.addItemDecoration(DividerItemDecoration(activity, DividerItemDecoration.VERTICAL))
    }

    private fun subscribe(){
        notesViewModel.notes.observe(viewLifecycleOwner, Observer { list->
            if (list != null){
                val adapter = notesRecyclerView.adapter
                if (adapter is NotesAdapter){
                    adapter.changeData(list)
                }
            }
        })
    }
    override fun onItemClick(position: Int) {
        notesList = notesViewModel.notes.value!!

        val chosenNoteTitle: String = notesList[position].noteTitle

        notesViewModel.selectedNotePosition.value = position

        Toast.makeText(context, "$chosenNoteTitle chosen", Toast.LENGTH_SHORT).show()
        findNavController().navigate(R.id.action_notesFragment_to_displayNoteFragment, null)
    }
    private fun setUpListeners(){
        addNoteButton.setOnClickListener {
            findNavController().navigate(R.id.action_notesFragment_to_newNoteFragment, null)
        }
    }

    private fun displayUserID(){
        userViewModel.userId.observe(viewLifecycleOwner, Observer {
            if (it != null && it.isNotBlank()) {
                userDisplayIDTextView.text = it
            }
        })
        userViewModel.userEmail.observe(viewLifecycleOwner, Observer {
            if (it != null && it.isNotBlank()) {
                userDisplayEmailTextView.text = it
            }
        })
    }
    private fun configDrawerMenu(){
//        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
        requireActivity().navigationView.menu.findItem(R.id.notesFragment).isVisible = false
        requireActivity().navigationView.menu.findItem(R.id.archiveFragment).isVisible = true
        requireActivity().navigationView.menu.findItem(R.id.loginFragment).isVisible = false
        requireActivity().navigationView.menu.findItem(R.id.logoutFragment).isVisible = true
        requireActivity().navigationView.menu.findItem(R.id.registerFragment).isVisible = false
    }
    private fun setUpAdMob(){
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
    }

    private fun encrypFile(fileName: String): EncryptedFile {
        val masterKeyAlias: String = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)

        val fileData = File(requireContext().filesDir, fileName)

        return EncryptedFile.Builder(fileData, requireContext(), masterKeyAlias, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build()
//        return EncryptedFile.Builder(requireContext(), fileData, masterKeyAlias, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build()
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun getInternalFiles(){
        val internalFilesList: Array<String> = requireContext().fileList()
        val notesInternalList = mutableListOf<Note>()

        for(file in internalFilesList) {

            if (file.endsWith(".txt")) {
                val fileName = File(file).nameWithoutExtension
                val noteTitle = fileName.split("_")[0]
                val noteDate = fileName.split("_")[1]
                var annotation = ""

                val noteAnnotations = encrypFile(file).openFileInput()

                val br = BufferedReader(InputStreamReader(noteAnnotations))
                br.lines().forEach {
                        t ->  annotation = t.toString()
                }
                noteAnnotations.close()

                val note = Note("", noteTitle, "", "", "", "", noteDate,annotation, "--°C", "","")
                notesInternalList.add(note)

            }
        }
        notesViewModel.notes.value = notesInternalList
        notesList = notesInternalList
    }

    private fun updateNotesFirebase(){
        firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes")
            .addSnapshotListener(EventListener { documentSnapshots, e ->
                if (e != null) {
                    return@EventListener
                }
                notesViewModel.notes.value = documentSnapshots!!.toObjects(Note::class.java)
            })
    }
}