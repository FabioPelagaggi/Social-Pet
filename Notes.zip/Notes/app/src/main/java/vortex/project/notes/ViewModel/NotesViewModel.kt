package vortex.project.notes.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import vortex.project.notes.Class.Note
import vortex.project.notes.Model.WeatherModel

class NotesViewModel : ViewModel() {
    var notes = MutableLiveData<List<Note>>()
    var selectedNotePosition = MutableLiveData<Int>()
    var cityLocal = MutableLiveData<String>()
}