package vortex.project.notes.Fragments

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.core.content.PermissionChecker
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKeys
import com.google.android.gms.auth.api.phone.SmsCodeAutofillClient.PermissionState.GRANTED
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.android.synthetic.main.fragment_new_note.*
import vortex.project.notes.Class.Encrypto
import vortex.project.notes.Class.Note
import vortex.project.notes.R
import vortex.project.notes.ViewModel.NotesViewModel
import vortex.project.notes.ViewModel.UserViewModel
import vortex.project.notes.ViewModel.WeatherViewModel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintWriter
import java.text.DateFormat
import java.util.*

class NewNoteFragment : Fragment() {

    private lateinit var notesViewModel: NotesViewModel
    private lateinit var weatherViewModel: WeatherViewModel
    private lateinit var userViewModel: UserViewModel
    private val REQUEST_IMAGE_CAPTURE = 1003
    private val REQUEST_PERMISSION_CODE = 1011
    private val REQUEST_PERMISSION_REQUEST_CODE = 2020
    private val encrypto = Encrypto()
    private var encodedImageString = ""
    private var newNoteID = ""

    private var firestoreDB: FirebaseFirestore? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        firestoreDB = FirebaseFirestore.getInstance()
        return inflater.inflate(R.layout.fragment_new_note, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let { act ->
            notesViewModel = ViewModelProvider(act).get(NotesViewModel::class.java)
            weatherViewModel = ViewModelProvider(act).get(WeatherViewModel::class.java)
            userViewModel = ViewModelProvider(act).get(UserViewModel::class.java)
        }

        setUpListeners()
    }

    private fun setUpListeners(){
        newNoteConfirmNote_Button.setOnClickListener {
            addNote()
//            saveOnLocalFile()
            findNavController().navigate(R.id.action_newNoteFragment_to_notesFragment, null)
        }

        newNoteCancelNote_Button.setOnClickListener{
            findNavController().navigate(R.id.action_newNoteFragment_to_notesFragment, null)
        }

        addLocation_ImageButton.setOnClickListener{
            if (checkSelfPermission(requireActivity(),Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                getCurrentLocation()
            } else if(shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                displayDialogPermission("Access to the Location required to use this feature.", arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
            } else {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_PERMISSION_REQUEST_CODE)
            }
        }

        addPhoto_ImageButton.setOnClickListener{
            if (PermissionChecker.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PermissionChecker.PERMISSION_GRANTED){
                callCameraApp()
            } else if(shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                displayDialogPermission("Access to the camera required to use this feature.", arrayOf(Manifest.permission.CAMERA))
            } else {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_IMAGE_CAPTURE)
            }
        }

        newNoteWeather_CardView.setOnClickListener{
            getWeather()
        }
    }

    private fun callCameraApp(){
        val capturaImagemIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        try {
            startActivityForResult(capturaImagemIntent, REQUEST_IMAGE_CAPTURE)
        } catch (e: Exception) {
            Toast.makeText(context, "${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                try {
                    newNotePhoto_ImageView.visibility = View.VISIBLE
                    val imageBitmap = data!!.extras!!["data"] as Bitmap?
                    newNotePhoto_ImageView.setImageBitmap(imageBitmap)

                    val baos = ByteArrayOutputStream()
                    imageBitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, baos)
                    val b: ByteArray = baos.toByteArray()
                    encodedImageString = Base64.encodeToString(b, Base64.DEFAULT)

                } catch (e: Exception) {
                    Toast.makeText(context, "${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun displayDialogPermission(message: String, permissions: Array<String>) {
        val alertDialog = AlertDialog
            .Builder(requireContext())
            .setTitle("Permissions")
            .setMessage(message)
            .setPositiveButton("Ok") {
                    dialog, _ -> requestPermissions(permissions, REQUEST_PERMISSION_CODE)
                    dialog.dismiss()
            }.setNegativeButton("Cancel") {
                    dialog, _ ->
                    dialog.dismiss()
            }
        alertDialog.show()
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {

        location_ProgressBar.visibility = View.VISIBLE

        val locationRequest = LocationRequest()
        locationRequest.interval = 10000
        locationRequest.fastestInterval = 5000
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        val geocoder = Geocoder(requireActivity(), Locale.getDefault())
        var addresses:List<Address>

        LocationServices.getFusedLocationProviderClient(requireActivity())
            .requestLocationUpdates(locationRequest,object : LocationCallback(){
                override fun onLocationResult(locationResult: LocationResult?) {
                    super.onLocationResult(locationResult)
                    LocationServices.getFusedLocationProviderClient(requireActivity())
                        .removeLocationUpdates(this)
                    if (locationResult != null && locationResult.locations.size > 0){
                        val locIndex = locationResult.locations.size-1

                        val latitude = locationResult.locations[locIndex].latitude
                        val longitude = locationResult.locations[locIndex].longitude

                        addresses = geocoder.getFromLocation(latitude,longitude,1)
                        notesViewModel.cityLocal.value = addresses[0].locality

                        val address:String = addresses[0].getAddressLine(0)
                        newNoteLocation_CardView.visibility = View.VISIBLE
                        newNoteLatitude_CardView.visibility = View.VISIBLE
                        newNoteLongitude_CardView.visibility = View.VISIBLE
                        newNoteLocation_TextView.text = address
                        newNoteLatitude_TextView.text = latitude.toString()
                        newNoteLongitude_TextView.text = longitude.toString()
                        if (newNoteLocation_TextView != null){
                            location_ProgressBar.visibility = View.GONE
                        }
                        newNoteWeather_CardView.visibility = View.VISIBLE
                    }
                }
            }, Looper.getMainLooper())

    }

    private fun addNote(){
        val newNote = Note(
            "",
            noteTitle_EditText.text.toString(),
            encodedImageString,
            newNoteLocation_TextView.text.toString(),
            newNoteLatitude_TextView.text.toString(),
            newNoteLongitude_TextView.text.toString(),
            getDate(),
            annotations_EditText.text.toString(),
            newNoteWeatherCelsius_TextView.text.toString(),
            newNoteHumidity_TextView.text.toString(),
            newNoteWind_TextView.text.toString()
        )
        val list = notesViewModel.notes.value?: listOf()

        notesViewModel.notes.value = list + newNote
//        writeInAInternalFile()
        addNoteFirebase(newNote)
    }

    private fun getDate(): String {
        val date = Calendar.getInstance().time
        return DateFormat.getDateInstance(DateFormat.LONG).format(date)
    }

    private fun encrypFile(fileName: String): EncryptedFile{
        val masterKeyAlias: String = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)

        val fileData = File(requireContext().filesDir, fileName)

        return EncryptedFile.Builder(fileData, requireContext(), masterKeyAlias, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build()
    }

    private fun writeInAInternalFile(){
        val noteTitle = noteTitle_EditText.text.toString()
        val noteAnnotation = annotations_EditText.text.toString()
//        var notePhoto: String? = null

        val noteDate = getDate()

        val fileNameTxt = "${noteTitle}_${noteDate}_.txt"
//        val fileNameFig = "${noteTitle}_${noteDate}_.fig"

        deleteFile(fileNameTxt)

        val encrypFile = encrypFile(fileNameTxt).openFileOutput()
        val pw = PrintWriter(encrypFile)
        pw.println(noteAnnotation)
        pw.flush()
        encrypFile.close()
    }

    private fun deleteFile(fileName: String){
        val file = File(requireActivity().filesDir, fileName)

        if (file.exists()) {
            file.delete()
        }
    }

    private fun getWeather(){
        getWeather_TextView.visibility = View.GONE
        weatherProgressBar.visibility = View.VISIBLE

        weatherViewModel.refreshData(notesViewModel.cityLocal.value!!)

        weatherUpdate()

    }

    @SuppressLint("SetTextI18n")
    private fun weatherUpdate(){
        weatherViewModel.weatherData.observe(viewLifecycleOwner,
            {
                if(it != null){
                    newNoteWeatherCelsius_TextView.text = it.main.temp.toString() + "°C"
                    newNoteHumidity_TextView.text = it.main.humidity.toString() + "%"
                    newNoteWind_TextView.text = it.wind.speed.toString()

                    weatherProgressBar.visibility = View.GONE
                    newNoteWeatherCelsius_TextView.visibility = View.VISIBLE
                    newNoteHumidity_CardView.visibility = View.VISIBLE
                    newNoteWind_CardView.visibility = View.VISIBLE
                    Toast.makeText(context, "Weather Success", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun addNoteFirebase(newNote: Note){

        firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes")
            .add(newNote)
            .addOnSuccessListener { documentReference ->
                newNoteID = documentReference.id
                val data = hashMapOf("noteID" to newNoteID)
                firestoreDB!!.collection("Users").document(userViewModel.userId.value.toString()).collection("Notes").document(newNoteID)
                    .set(data, SetOptions.merge())
                Log.e(ContentValues.TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                Toast.makeText(context, "Note has been added to firebase store!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e(ContentValues.TAG, "Error adding note document", e)
                Toast.makeText(context, "Note could not be added to firebase store...", Toast.LENGTH_SHORT).show()
            }
    }
}


