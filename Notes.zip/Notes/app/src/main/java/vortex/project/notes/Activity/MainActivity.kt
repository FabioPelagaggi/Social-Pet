package vortex.project.notes.Activity

import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.facebook.login.LoginManager
import com.google.android.gms.ads.MobileAds
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*
import vortex.project.notes.R
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

class MainActivity : AppCompatActivity() {

    lateinit var toogle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        printHashKey()

        MobileAds.initialize(this) {}

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.navigationView)

        toogle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toogle)
        toogle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(false)
//        configDrawerMenu()

        navView.setNavigationItemSelectedListener {
            when(it.itemId){
                R.id.notesFragment -> {
                    Toast.makeText(applicationContext, "Clicked on Notes", Toast.LENGTH_SHORT).show()
                    Navigation.findNavController(this, R.id.fragmentNav).navigate(R.id.notesFragment)
                }
                R.id.archiveFragment -> {Toast.makeText(applicationContext, "Clicked on Archive", Toast.LENGTH_SHORT).show()
//                    Navigation.findNavController(this, R.id.fragmentNav).navigate(R.id.archiveFragment)
                }
                R.id.loginFragment -> {Toast.makeText(applicationContext, "Clicked on Log In", Toast.LENGTH_SHORT).show()
                    Navigation.findNavController(this, R.id.fragmentNav).navigate(R.id.loginFragment)
                }
                R.id.logoutFragment -> {Toast.makeText(applicationContext, "Clicked on Log Out", Toast.LENGTH_SHORT).show()
                    logout()
//                    configDrawerMenu()
                }
                R.id.registerFragment -> {Toast.makeText(applicationContext, "Clicked on Register", Toast.LENGTH_SHORT).show()
                    Navigation.findNavController(this, R.id.fragmentNav).navigate(R.id.registerFragment)
                }
            }
            true
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(toogle.onOptionsItemSelected(item)){true}
        return super.onOptionsItemSelected(item)
    }

    private fun logout(){
        FirebaseAuth.getInstance().signOut()
        LoginManager.getInstance().logOut()
        Toast.makeText(this, "Log Out Successfully", Toast.LENGTH_SHORT).show()
        Navigation.findNavController(this, R.id.fragmentNav).navigate(R.id.loginFragment)
    }
    fun test(){

    }
    private fun printHashKey() {
        try {
            val info = packageManager.getPackageInfo(
                "vortex.project.notes",
                PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {

        } catch (e: NoSuchAlgorithmException) {

        }
    }

//    private fun configDrawerMenu(){
////        supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        navigationView.menu.findItem(R.id.notesFragment).isVisible = false
//        navigationView.menu.findItem(R.id.archiveFragment).isVisible = false
//        navigationView.menu.findItem(R.id.loginFragment).isVisible = false
//        navigationView.menu.findItem(R.id.logoutFragment).isVisible = false
//        navigationView.menu.findItem(R.id.registerFragment).isVisible = true
//    }
}